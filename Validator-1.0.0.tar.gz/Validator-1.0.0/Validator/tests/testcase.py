#!/usr/bin/env python

import unittest
from Validator.src import passwordValidator


class PasswordTestCase(unittest.TestCase):
    """Tests for `password_validator`."""
    def test_is_short_characters(self):
        """Is password check for short_character ?"""
        self.assertFalse(passwordValidator.PasswordValidator.length_check('mom'))

if __name__ == '__main__':
    unittest.main()